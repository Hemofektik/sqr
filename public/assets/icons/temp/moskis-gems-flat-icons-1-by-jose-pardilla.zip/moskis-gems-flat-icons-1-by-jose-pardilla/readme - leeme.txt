
ENGLISH

This pack is shared under a Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) license.
http://creativecommons.org/licenses/by-sa/3.0/deed.en

While it's not mandatory to credit the author, it is very appreciated, since you help spread the word.
If you choose to credit the author you can link to http://josepardilla.com/


I claim no right of ownership to the respective company logos and glyphs in each one of these icons.


-------------------------------------

SPANISH

Este pack se distribuye bajo una licencia Creative Commons Atribuci�n-CompartirIgual 3.0 Unported (CC BY-SA 3.0).
http://creativecommons.org/licenses/by-sa/3.0/deed.es

Aunque no es obligatorio enlazar al autor para usarlo, se aprecia mucho, ya que permite dar a conocer el pack a otros usuarios.
Si decides enlazar al autor puedes hacerlo usando este link: http://josepardilla.com/


Los logos y s�mbolos contenidos en este pack son propiedad de sus respectivos due�os.


-------------------------------------

ENGLISH

Tanks for downloading Moskis Gems: Social Pack #1
released by Jos� Pardilla in collaboration with Ontuts (http://web.ontuts.com/).

As the name suggests, there will be updates and more packs,
you can keep updated about them at http://josepardilla.com/ or folowing me on twitter @moskis

This pack contains:

- 60 PNG 32x32 3D icons in three editions: Shadow, Shadowless & Glow.
The Shadowless edition will look good on both light and dark backgrounds.
The other two editions are optimized for light backgrounds.

- 60 PNG 32x30 icons in three editions: Shadow, Shadowless & Glow.
The Shadowless edition will look good on both light and dark backgrounds.
The other two editions are optimized for light backgrounds.

This pack is inspired by some of the work by Manuel L�pez (emey87): http://emey87.deviantart.com/gallery/

If you love the pack as much as me, you can help me make more donating to PayPal: jose@moskis.net

Also, i'm usually available for WordPress consulting and customization,
you can see my porftolio and contact me from http://josepardilla.com/


-------------------------------------

SPANISH

Gracias por descargar Moskis Gems: Social Pack #1
lanzado por Jos� Pardilla en colaboraci�n con Ontuts (http://web.ontuts.com/).

Como el nombre sugiere, habr�n actualizaciones y m�s packs,
puedes mantenerte informado en http://josepardilla.com/ o sigu�endome en twitter @moskis

El pack contiene:

- 60 iconos PNG 32x32 3D en tres formatos, Con Sombra, Sin Sombra y Con Brillo.
La versi�n Sin Sombra se ve sin problemas en fondos tanto claros como oscuros.
Las otras dos versi�n est�n optimizadas para fondos claros.

- 60 iconos PNG 32x30 en tres formatos, Con Sombra, Sin Sombra y Con Brillo.
La versi�n Sin Sombra se ve sin problemas en fondos tanto claros como oscuros.
Las otras dos versi�n est�n optimizadas para fondos claros.

Este pack est� inspirado en algunos trabajos de Manuel L�pez (emey87): http://emey87.deviantart.com/gallery/

Si te gusta el pack tanto como al autor, puedes ayudar a hacer m�s haciendo una donaci�n a esta cuenta de PayPal: jose@moskis.net

Tambi�n estoy disponible para consultor�a y personalizaci�n de webs basadas en WordPress,
Puedes ver mi portfolio y contactarme desde http://josepardilla.com/
